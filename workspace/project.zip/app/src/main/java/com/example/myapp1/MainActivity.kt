package com.example.myapp1

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

class MainActivity : ComponentActivity() {

    // State to hold the chosen video URI (either from file manager or local asset fallback)
    private var selectedVideoUri by mutableStateOf<Uri?>(null)

    // Secure system file picker contract
    private val pickVideoLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { selectedUri ->
            val flag = Intent.FLAG_GRANT_READ_URI_PERMISSION
            contentResolver.takePersistableUriPermission(selectedUri, flag)
            selectedVideoUri = selectedUri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Load the bundled local asset video.mp4 by default if no file is chosen yet
        // Make sure you place video.mp4 inside app/src/main/assets/
        val assetUri = Uri.parse("android.asset:///video.mp4")
        if (selectedVideoUri == null) {
            selectedVideoUri = assetUri
        }

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VideoPickerAndPlayerScreen(
                        videoUri = selectedVideoUri,
                        onSelectVideo = {
                            // Launch system file picker filtering for video files
                            pickVideoLauncher.launch(arrayOf("video/*"))
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun VideoPickerAndPlayerScreen(
    videoUri: Uri?,
    onSelectVideo: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        
        Text(
            text = "Video Player App",
            fontSize = 24.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 1. Select Video Button at the Top
        Button(onClick = onSelectVideo) {
            Text("Select Video from File Manager")
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Video Player positioned directly BELOW the button
        if (videoUri != null) {
            AndroidView(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp), // Adjust height of the player window as needed
                factory = { context ->
                    VideoView(context).apply {
                        val mediaController = MediaController(context)
                        mediaController.setAnchorView(this)
                        setMediaController(mediaController)
                        setVideoURI(videoUri)
                        setOnPreparedListener {
                            start()
                        }
                    }
                },
                update = { videoView ->
                    videoView.setVideoURI(videoUri)
                    videoView.start()
                }
            )
        }
    }
}
