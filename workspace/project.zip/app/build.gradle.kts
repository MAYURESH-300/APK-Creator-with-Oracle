plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.myapp1"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.myapp1"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildFeatures {
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

configurations.all {
    resolutionStrategy {
        force("androidx.compose.ui:ui:1.6.2")
        force("androidx.compose.ui:ui-graphics:1.6.2")
        force("androidx.compose.ui:ui-text:1.6.2")
        force("androidx.compose.foundation:foundation:1.6.2")
        force("androidx.compose.foundation:foundation-layout:1.6.2")
        force("androidx.compose.animation:animation:1.6.2")
        force("androidx.compose.animation:animation-core:1.6.2")
        force("androidx.compose.material3:material3:1.2.0")
        force("androidx.compose.runtime:runtime:1.6.2")
        force("androidx.compose.runtime:runtime-saveable:1.6.2")
        force("androidx.compose.material:material-ripple:1.6.2")
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
      implementation("androidx.media3:media3-exoplayer:1.2.1")
implementation("androidx.media3:media3-ui:1.2.1")
implementation("androidx.compose.material:material-icons-extended:1.6.0")
  }